/**
 * 核心模块 - DOM缓存、快捷访问器、配置数据
 * 依赖：无（基础模块）
 */

// ============ P0 性能优化：DOM 缓存机制 ============
const DOMCache = {
    _cache: new Map(),
    _listeners: new Map(),
    _delegatedParents: new Map(),

    get(id) {
        if (!this._cache.has(id)) {
            const el = document.getElementById(id);
            if (el) this._cache.set(id, el);
        }
        return this._cache.get(id);
    },

    query(selector, root = document) {
        const key = `q:${selector}`;
        if (!this._cache.has(key)) {
            const el = root.querySelector(selector);
            if (el) this._cache.set(key, el);
        }
        return this._cache.get(key);
    },

    queryAll(selector, root = document) {
        const key = `qa:${selector}`;
        if (!this._cache.has(key)) {
            const els = Array.from(root.querySelectorAll(selector));
            this._cache.set(key, els);
        }
        return this._cache.get(key);
    },

    invalidate(key) {
        this._cache.delete(key);
    },

    invalidateByPrefix(prefix) {
        for (const key of this._cache.keys()) {
            if (key.startsWith(prefix)) this._cache.delete(key);
        }
    },

    clear() {
        this._cache.clear();
    },

    // 事件委托：在父元素上绑定一次监听器
    delegate(parentSelector, eventType, targetSelector, handler) {
        const key = `${parentSelector}:${eventType}:${targetSelector}`;
        if (this._delegatedParents.has(key)) return;

        const parent = typeof parentSelector === 'string'
            ? (parentSelector === document ? document : this.query(parentSelector) || document.querySelector(parentSelector))
            : parentSelector;

        if (!parent) return;

        const wrappedHandler = (e) => {
            const target = e.target.closest(targetSelector);
            if (target && parent.contains(target)) {
                handler.call(target, e, target);
            }
        };

        parent.addEventListener(eventType, wrappedHandler);
        this._delegatedParents.set(key, { parent, handler: wrappedHandler });
    }
};

// 常用 DOM 元素快捷访问器（延迟初始化）
const $ = {
    get charName() { return DOMCache.get('character-name'); },
    get playerName() { return DOMCache.get('player-name'); },
    get occupationPoints() { return DOMCache.get('occupation-points'); },
    get interestPoints() { return DOMCache.get('interest-points'); },
    get occupationRemaining() { return DOMCache.get('occupation-remaining'); },
    get interestRemaining() { return DOMCache.get('interest-remaining'); },

    get str() { return DOMCache.get('str'); },
    get con() { return DOMCache.get('con'); },
    get siz() { return DOMCache.get('siz'); },
    get dex() { return DOMCache.get('dex'); },
    get app() { return DOMCache.get('app'); },
    get int() { return DOMCache.get('int'); },
    get pow() { return DOMCache.get('pow'); },
    get edu() { return DOMCache.get('edu'); },
    get luc() { return DOMCache.get('luc'); },

    get healthMax() { return DOMCache.query('.health-max'); },
    get healthCurrent() { return DOMCache.query('.health-current'); },
    get healthTemp() { return DOMCache.query('.health-temp'); },
    get magicMax() { return DOMCache.query('.magic-max'); },
    get magicCurrent() { return DOMCache.query('.magic-current'); },
    get magicTemp() { return DOMCache.query('.magic-temp'); },
    get sanityStart() { return DOMCache.query('.sanity-start'); },
    get sanityMax() { return DOMCache.query('.sanity-max'); },
    get sanityCurrent() { return DOMCache.query('.sanity-current'); },

    get damageBonus() { return DOMCache.get('damage-bonus'); },
    get spiritBonus() { return DOMCache.get('spirit-bonus'); },
    get build() { return DOMCache.get('build'); },
    get armor() { return DOMCache.get('armor'); },

    get skillsContainer() { return DOMCache.query('.skills-container'); },
    get skillsLeftColumn() { return DOMCache.query('.skills-column.left-column'); },
    get skillsRightColumn() { return DOMCache.query('.skills-column.right-column'); },
    get totalAttr() { return DOMCache.query('.total-attr'); },

    get customSkillsBody() { return DOMCache.get('custom-skills-body'); },
    get itemsBody() { return DOMCache.get('items-body'); },
    get notesBody() { return DOMCache.get('notes-body'); },

    get customCharacterName() { return DOMCache.get('custom-character-name'); },
    get itemsCharacterName() { return DOMCache.get('items-character-name'); },
    get notesCharacterName() { return DOMCache.get('notes-character-name'); }
};

// 技能数据
const skillsData = [
    { name: "信用评级", base: 0 },
    { name: "克苏鲁神话", base: 0 },
    { name: "侦查", base: 25 },
    { name: "聆听", base: 20 },
    { name: "图书馆使用", base: 20 },
    { name: "计算机使用", base: 5 },
    { name: "潜行", base: 20 },
    { name: "追踪", base: 10 },
    { name: "导航", base: 10 },
    { name: "话术", base: 5 },
    { name: "说服", base: 10 },
    { name: "取悦", base: 15 },
    { name: "恐吓", base: 15 },
    { name: "心理学", base: 10 },
    { name: "母语", base: "edu", subtypes: ["汉语", "英语", "日语", "法语", "俄语", "德语", "韩语", "粤语", "拉丁语", "荷兰语", "挪威语", "丹麦", "印度语", "西班牙语", "葡萄牙语", "阿拉伯语"], rows: 1 },
    { name: "外语", base: 1, subtypes: ["汉语", "英语", "日语", "法语", "俄语", "德语", "韩语", "粤语", "拉丁语", "荷兰语", "挪威语", "丹麦", "印度语", "西班牙语", "葡萄牙语", "阿拉伯语"], rows: 2 },
    { name: "闪避", base: "halfDex" },
    { name: "格斗", base: -1, subtypes: [
        { name: "斗殴", base: 25 },
        { name: "链锯", base: 10 },
        { name: "刀剑", base: 20 },
        { name: "矛", base: 20 },
        { name: "斧", base: 15 },
        { name: "绞索", base: 15 },
        { name: "链枷", base: 10 },
        { name: "鞭", base: 5 }
    ], rows: 3 },
    { name: "射击", base: -1, subtypes: [
        { name: "手枪", base: 20 },
        { name: "步枪/霰弹枪", base: 25 },
        { name: "冲锋枪", base: 15 },
        { name: "弓弩", base: 15 },
        { name: "机枪", base: 10 },
        { name: "重武器", base: 10 }
    ], rows: 3 },
    { name: "投掷", base: 20 },
    { name: "急救", base: 30 },
    { name: "医学", base: 1 },
    { name: "精神分析", base: 1 },
    { name: "攀爬", base: 20 },
    { name: "跳跃", base: 20 },
    { name: "游泳", base: 20 },
    { name: "博物学", base: 10 },
    { name: "神秘学", base: 5 },
    { name: "考古学", base: 1 },
    { name: "人类学", base: 1 },
    { name: "估价", base: 5 },
    { name: "会计", base: 5 },
    { name: "法律", base: 5 },
    { name: "历史", base: 5 },
    { name: "电子学", base: 1 },
    { name: "科学", base: -1, subtypes: [
        { name: "数学", base: 10 },
        { name: "地质学", base: 1 },
        { name: "化学", base: 1 },
        { name: "生物学", base: 1 },
        { name: "天文学", base: 1 },
        { name: "物理", base: 1 },
        { name: "药学", base: 1 },
        { name: "植物学", base: 1 },
        { name: "动物学", base: 1 },
        { name: "密码学", base: 1 },
        { name: "工程学", base: 1 },
        { name: "气象学", base: 1 },
        { name: "鉴证", base: 1 }
    ], rows: 3 },
    { name: "乔装", base: 5 },
    { name: "妙手", base: 10 },
    { name: "锁匠", base: 1 },
    { name: "机械维修", base: 10 },
    { name: "电气维修", base: 10 },
    { name: "驯兽", base: 5 },
    { name: "技艺", base: -1, subtypes: [
        { name: "表演", base: 5 },
        { name: "音乐", base: 5 },
        { name: "绘画", base: 5 },
        { name: "艺术", base: 5 },
        { name: "摄影", base: 5 },
        { name: "写作", base: 5 },
        { name: "书法", base: 5 },
        { name: "打字", base: 5 },
        { name: "速记", base: 5 },
        { name: "伪造", base: 5 },
        { name: "烹饪", base: 5 },
        { name: "裁缝", base: 5 },
        { name: "理发", base: 5 },
        { name: "技术制图", base: 5 },
        { name: "耕作", base: 5 },
        { name: "木工", base: 5 },
        { name: "铁匠", base: 5 },
        { name: "焊接", base: 5 },
        { name: "管道工", base: 5 }
    ], rows: 3 },
    { name: "生存", base: -1, subtypes: [
        { name: "沙漠", base: 5 },
        { name: "森林", base: 5 },
        { name: "荒岛", base: 5 },
        { name: "高山", base: 5 },
        { name: "海上", base: 5 }
    ], rows: 3 },
    { name: "汽车驾驶", base: 20 },
    { name: "骑术", base: 5 },
    { name: "重型机械", base: 1 },
    { 
        name: "驾驶", 
        base: -1, 
        subtypes: [
            { name: "船", base: 1 },
            { name: "马车", base: 1 },
            { name: "飞行器", base: 1 }
        ], 
        rows: 3 
    }
];

// 默认笔记配置（名称固定，仅可编辑备注）
// globalPos 为左列偶数位置，collectNotes / loadNotes / initNotesTable 共用此定义
const DEFAULT_NOTES = [
    { name: '贡献', type: '其他', globalPos: 0 },
    { name: '幕间', type: '其他', globalPos: 2 },
    { name: '修炼', type: '其他', globalPos: 4 }
];
const DEFAULT_NOTE_POSITIONS = DEFAULT_NOTES.map(n => n.globalPos);

// ============ 发布-订阅系统（EventBus） ============
const EventBus = {
    _events: new Map(),

    on(event, callback) {
        if (!this._events.has(event)) {
            this._events.set(event, new Set());
        }
        this._events.get(event).add(callback);
        return () => this.off(event, callback);
    },

    off(event, callback) {
        if (this._events.has(event)) {
            this._events.get(event).delete(callback);
        }
    },

    emit(event, data) {
        if (this._events.has(event)) {
            this._events.get(event).forEach(callback => {
                try {
                    callback(data);
                } catch (e) {
                    console.error(`Error in EventBus handler for "${event}":`, e);
                }
            });
        }
    },

    clear() {
        this._events.clear();
    }
};

// ============ 角色数据 Store（状态管理） ============
// 说明：当前 Store 仅承担"属性/角色名变更 → 事件分发"的职责，
// HP/MP/Sanity 等状态值仍由各模块直接读写 DOM，未纳入 Store。
const CharacterStore = {
    _state: {
        characterName: '',
        attributes: {}
    },

    // 更新角色名（自动同步到所有Tab）
    setCharacterName(name) {
        this._state.characterName = name;
        // 发布事件，通知所有订阅者
        EventBus.emit('characterName', name);
    },

    // 更新单个属性
    setAttribute(key, value) {
        this._state.attributes[key] = value;
        EventBus.emit('attribute', { key, value });
    },

    // 批量更新属性
    setAttributes(attrs) {
        Object.assign(this._state.attributes, attrs);
        EventBus.emit('attributes', attrs);
    }
};

// ============ 角色管理器（多角色数据隔离） ============
// localStorage 键：
//   'characterIndex'        → [{id, name, occupation, updatedAt, createdAt}]
//   'characterData:{id}'    → 单个角色完整 characterData
//   'currentCharacterId'    → 当前活跃角色 ID
const CharacterManager = {
    INDEX_KEY: 'characterIndex',
    CURRENT_ID_KEY: 'currentCharacterId',
    DATA_KEY_PREFIX: 'characterData:',

    /** 生成唯一角色 ID */
    _genId() {
        return 'ch_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 8);
    },

    /** 获取角色索引数组 */
    getIndex() {
        try {
            const raw = localStorage.getItem(this.INDEX_KEY);
            return raw ? JSON.parse(raw) : [];
        } catch (e) {
            console.error('读取角色索引失败:', e);
            return [];
        }
    },

    /** 持久化索引 */
    _saveIndex(index) {
        localStorage.setItem(this.INDEX_KEY, JSON.stringify(index));
    },

    /** 获取当前活跃角色 ID */
    getCurrentId() {
        return localStorage.getItem(this.CURRENT_ID_KEY) || null;
    },

    /** 设置当前活跃角色 ID */
    setCurrentId(id) {
        if (id) {
            localStorage.setItem(this.CURRENT_ID_KEY, id);
        } else {
            localStorage.removeItem(this.CURRENT_ID_KEY);
        }
    },

    /** 构造单角色存储 key */
    _dataKey(id) {
        return this.DATA_KEY_PREFIX + id;
    },

    /** 读取单角色完整数据 */
    getCharacterData(id) {
        try {
            const raw = localStorage.getItem(this._dataKey(id));
            return raw ? JSON.parse(raw) : null;
        } catch (e) {
            console.error(`读取角色数据失败 [${id}]:`, e);
            return null;
        }
    },

    /** 写入单角色完整数据 */
    setCharacterData(id, data) {
        // 修复 S1：不吞 QuotaExceededError，让其冒泡到 saveCharacter 的 catch 统一提示
        localStorage.setItem(this._dataKey(id), JSON.stringify(data));
    },

    /** 删除单角色数据与索引条目 */
    deleteCharacter(id) {
        const index = this.getIndex().filter(item => item.id !== id);
        this._saveIndex(index);
        localStorage.removeItem(this._dataKey(id));
        if (this.getCurrentId() === id) {
            this.setCurrentId(index[0]?.id || null);
        }
    },

    /** 更新索引的元信息（name/occupation/updatedAt），从 characterData 提取 */
    refreshMeta(id) {
        const index = this.getIndex();
        const data = this.getCharacterData(id);
        if (!data) return;
        const item = index.find(x => x.id === id);
        if (item) {
            item.name = data.basic?.characterName || '未命名角色';
            item.occupation = data.basic?.occupation || '';
            item.updatedAt = Date.now();
            this._saveIndex(index);
        }
    },

    /** 新建角色，返回新角色 ID（空角色，未写入数据，等首次 save） */
    createCharacter(name = '未命名角色') {
        const index = this.getIndex();
        const id = this._genId();
        index.unshift({
            id,
            name,
            occupation: '',
            createdAt: Date.now(),
            updatedAt: Date.now()
        });
        this._saveIndex(index);
        this.setCurrentId(id);
        return id;
    },

    /** 将完整 characterData 导入为一个新角色（导入功能使用） */
    importAsNewCharacter(characterData, suggestName) {
        const index = this.getIndex();
        const id = this._genId();
        const name = suggestName || characterData.basic?.characterName || '导入角色';
        index.unshift({
            id,
            name,
            occupation: characterData.basic?.occupation || '',
            createdAt: Date.now(),
            updatedAt: Date.now()
        });
        this._saveIndex(index);
        this.setCharacterData(id, characterData);
        this.setCurrentId(id);
        return id;
    },

    /** 重命名角色条目名 */
    renameCharacter(id, newName) {
        const index = this.getIndex();
        const item = index.find(x => x.id === id);
        if (item) {
            item.name = newName || '未命名角色';
            item.updatedAt = Date.now();
            this._saveIndex(index);
        }
    },

    /**
     * 迁移旧单角色数据：
     *   若存在旧键 'characterData' 且索引为空，则迁移为第一个角色并清除旧键。
     */
    migrateLegacySingleCharacter() {
        const legacyRaw = localStorage.getItem('characterData');
        if (!legacyRaw) return null;
        const index = this.getIndex();
        if (index.length > 0) {
            // 索引已存在，不做迁移；但旧键仍保留（以防万一）
            return null;
        }
        try {
            const legacyData = JSON.parse(legacyRaw);
            if (!legacyData || !legacyData.basic) return null;
            const name = legacyData.basic.characterName || '已存角色';
            const occupation = legacyData.basic.occupation || '';
            const id = this._genId();
            const newIndex = [{
                id,
                name,
                occupation,
                createdAt: Date.now(),
                updatedAt: Date.now()
            }];
            this._saveIndex(newIndex);
            this.setCharacterData(id, legacyData);
            this.setCurrentId(id);
            localStorage.removeItem('characterData');
            return id;
        } catch (e) {
            console.error('迁移旧单角色失败:', e);
            return null;
        }
    }
};

// ============ 订阅者注册（在DOMReady后调用） ============
function setupEventBusSubscribers() {
    // 订阅角色名变更 - 同步到所有Tab的姓名显示
    EventBus.on('characterName', (name) => {
        const customName = document.getElementById('custom-character-name');
        const itemsName = document.getElementById('items-character-name');
        const notesName = document.getElementById('notes-character-name');
        const growthName = document.getElementById('growth-character-name');

        if (customName) customName.textContent = name;
        if (itemsName) itemsName.textContent = name;
        if (notesName) notesName.textContent = name;
        if (growthName) growthName.textContent = name || '未命名';
    });

    // 订阅属性变更 - 触发衍生计算
    EventBus.on('attribute', ({ key }) => {
        // 触发衍生属性更新
        if (typeof updateDerivedStats === 'function') {
            updateDerivedStats();
        }
        // 特定属性触发额外更新
        if (key === 'dex' && typeof updateDodgeBaseValue === 'function') {
            updateDodgeBaseValue();
        }
        if (key === 'edu' && typeof updateMotherTongueBaseValue === 'function') {
            updateMotherTongueBaseValue();
        }
    });

    // 订阅属性批量变更
    EventBus.on('attributes', () => {
        if (typeof updateDerivedStats === 'function') {
            updateDerivedStats();
        }
        if (typeof updateTotalPoints === 'function') {
            updateTotalPoints();
        }
    });

    // 订阅技能变更
    EventBus.on('skill', (skillData) => {
        if (skillData?.name?.includes('克苏鲁神话') && typeof updateDerivedStats === 'function') {
            updateDerivedStats();
        }
    });
}

// ============ 通用消息/确认模态框（替代原生 alert/confirm） ============
// 简易 HTML 转义，避免消息文本注入
function _escapeMessageText(str) {
    if (str == null) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}

// 显示提示消息（替代 alert），支持可选标题
function showMessage(message, title = '提示') {
    return new Promise((resolve) => {
        const modal = document.getElementById('message-modal');
        const titleEl = document.getElementById('message-modal-title');
        const body = document.getElementById('message-modal-body');
        const okBtn = document.getElementById('message-modal-ok');
        const cancelBtn = document.getElementById('message-modal-cancel');

        if (!modal || !okBtn) {
            // 兜底：若 DOM 尚未就绪，退回 alert
            alert(message);
            resolve(false);
            return;
        }

        titleEl.textContent = title;
        body.innerHTML = _escapeMessageText(message).replace(/\n/g, '<br>');

        // alert 模式：隐藏取消按钮
        cancelBtn.classList.add('is-hidden');

        const close = (result) => {
            modal.classList.remove('active');
            okBtn.onclick = null;
            cancelBtn.onclick = null;
            modal.onclick = null;
            resolve(result);
        };

        okBtn.onclick = () => close(true);
        modal.onclick = (e) => { if (e.target === modal) close(false); };
        modal.classList.add('active');
    });
}

// 显示确认对话框（替代 confirm），返回 Promise<boolean>
function showConfirm(message, title = '确认') {
    return new Promise((resolve) => {
        const modal = document.getElementById('message-modal');
        const titleEl = document.getElementById('message-modal-title');
        const body = document.getElementById('message-modal-body');
        const okBtn = document.getElementById('message-modal-ok');
        const cancelBtn = document.getElementById('message-modal-cancel');

        if (!modal || !okBtn || !cancelBtn) {
            // 兜底
            resolve(confirm(message));
            return;
        }

        titleEl.textContent = title;
        body.innerHTML = _escapeMessageText(message).replace(/\n/g, '<br>');

        // confirm 模式：显示取消按钮
        cancelBtn.classList.remove('is-hidden');

        const close = (result) => {
            modal.classList.remove('active');
            okBtn.onclick = null;
            cancelBtn.onclick = null;
            modal.onclick = null;
            resolve(result);
        };

        okBtn.onclick = () => close(true);
        cancelBtn.onclick = () => close(false);
        modal.onclick = (e) => { if (e.target === modal) close(false); };
        modal.classList.add('active');
    });
}